# vcpkg

[Vcpkg](https://github.com/microsoft/vcpkg/) helps you manage C and C++
libraries on Windows, Linux and MacOS.

There is no curl package on vcpkg, only libcurl.

## Install libcurl

    vcpkg.exe install curl:x64-windows
