# HTTPS

HTTPS is in effect Secure HTTP. The secure part means that the TCP transport
layer is enhanced to provide authentication, privacy (encryption) and data
integrity by the use of TLS.

See the [Using TLS](../usingcurl/tls.md) section for in-depth details on how
to modify and tweak the TLS details in an HTTPS transfer.

* [HSTS](https/hsts.md)

