# The development team

Daniel Stenberg is the founder and self-proclaimed leader of the project.
Everybody else that participates or contributes in the project has thus
arrived at a later point. Some contributors worked for a while and then left
again. Most contributors hang around only for a short while to get their bug
fixed or feature merged or similar. Counting all contributors we know the
names of, we have received help from more than 3,300 individuals.

![curl contributors](contributors-over-time.svg)

More than 1,300 individuals have authored commits that have been merged into
the source code repository. Of course, many of those authors only ever
contributed a single commit so far.

![curl authors](authors.svg)

There is no formal membership or anything that needs to be done to join the
project. If you participate in communication or development, you are part of
the project. Every contributor decides for themselves exactly how much and in
what ways to participate.

The full list of people who ever did ten commits or more within a single year
in the project are in alphabetical order:

Alessandro Ghedini,
Ben Greear,
Benoit Neil,
Bill Hoffman,
Bill Nagel,
Björn Stenberg,
Brad Hards,
Christian Schmitz,
Dan Fandrich,
Daniel Gustafsson,
Daniel Stenberg,
Dominick Meglio,
Emanuele Torre,
Emil Engler,
Evgeny Grin,
Fabian Frank,
Fabian Keil,
Gergely Nagy,
Gisle Vanem,
Guenter Knauf,
Harry Sintonen,
Isaac Boukris,
Jacob Hoffman-Andrews,
Jakub Zakrzewski,
James Housley,
Jan Venekamp,
Jay Satiro,
Jiri Hruska,
Joe Mason,
Johannes Schindelin,
Josh Soref,
Julien Chaffraix,
Kamil Dudka,
Marc Hoersken,
Marcel Raad,
Mark Salisbury,
Marty Kuhrt,
Max Dymond,
Michael Kaufmann,
Michael Osipov,
Michal Marek,
Michał Antoniak,
Nicholas Nethercote,
Nick Zitzmann,
Nikos Mavrogiannopoulos,
Orgad Shaneh,
Patrick Monnerat,
Peter Wu,
Philip Heiduck,
Rikard Falkeborn,
Ruslan Baratov,
Ryan Schmidt,
Simon Warta,
Stefan Eissing,
Steinar H. Gunderson,
Sterling Hughes,
Steve Holme,
Svyatoslav Mishyn,
Tal Regev,
Tatsuhiro Tsujikawa,
Tor Arntsen,
Viktor Szakats,
Yang Tse
