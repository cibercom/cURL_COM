# Progress callback

This callback lets the application keep track of transfer progress. It is also
called on idle with the easy interface and is a common way to make libcurl
stop a transfer by returning error.

See the [progress callback](../callbacks/progress.md) section for all the
details.
