# Transfer control

An ongoing transfer can be controlled in several ways. The following pages
describe further details:

* [Stop](stop.md)
* [Stop slow transfers](stopslow.md)
* [Rate limit](ratelimit.md)
* [Progress meter](meter.md)
* [Progress callback](progress-callback.md)
