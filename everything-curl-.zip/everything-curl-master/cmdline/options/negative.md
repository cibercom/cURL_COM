# Negative options

For options that switch on something, boolean options, there is also a way to
switch them off. You then use the long form of the option with an initial
`no-` prefix before the name. As an example, to switch off verbose mode:

    curl --no-verbose http://example.com
