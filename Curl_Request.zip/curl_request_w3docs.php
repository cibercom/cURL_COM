<?php

// Set up cURL
$ch = curl_init('https://www.youtube.com');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Set up DELETE request
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

// Set up data for DELETE request (if applicable)
$data = ['key1' => 'value1', 'key2' => 'value2'];
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

// Send the request
$response = curl_exec($ch);

// Check for errors
if ($response === false) {
  die(curl_error($ch));
}

// Decode the response
$responseData = json_decode($response, true);

// Print the response data
print_r($responseData);

?>