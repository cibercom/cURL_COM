<?php

$url = "https://www.youtube.com"; // Replace with the actual URL

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");  // Set request method to DELETE
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    // Capture response

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

if ($http_code == 200) {
  echo "Resource deleted successfully!";
} else {
  echo "Error deleting resource: " . $http_code;
}

?>