<?php
// Initialize a new cURL session
$ch = curl_init();

// Specify the URL of the resource to be deleted
curl_setopt($ch, CURLOPT_URL, "https://youtube.com");

// Set the request method to DELETE
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

// Execute the cURL session
$response = curl_exec($ch);

// Handle any potential errors
if(curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

// Close the cURL session to free up resources
curl_close($ch);

?>