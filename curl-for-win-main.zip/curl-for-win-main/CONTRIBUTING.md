<!--
Copyright (C) Viktor Szakats
SPDX-License-Identifier: CC-BY-SA-4.0
-->
# How to contribute to curl-for-win

- Open your Issue, Pull Request or Discussion here:
  <https://github.com/curl/curl-for-win>

/ The curl team!
